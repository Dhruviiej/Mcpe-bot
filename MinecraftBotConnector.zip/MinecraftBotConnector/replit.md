# Replit.md - Minecraft Bot Control System

## Overview

This is a full-stack web application that provides a control interface for managing Minecraft bots. The application features a React frontend with real-time WebSocket communication to a Node.js/Express backend, allowing users to monitor and control Minecraft bot activities through a web interface.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Build Tool**: Vite for development and production builds
- **UI Library**: Radix UI components with shadcn/ui styling system
- **Styling**: Tailwind CSS with custom Minecraft-themed color palette
- **State Management**: React hooks with TanStack Query for server state
- **Routing**: Wouter for client-side routing
- **Real-time Communication**: WebSocket connection for live updates

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Real-time**: WebSocket server for bot communication
- **Session Management**: PostgreSQL session store
- **Bot Integration**: Mineflayer library for Minecraft bot control

### Database Schema
- **Users**: Authentication and user management
- **Bot Sessions**: Track bot connection states and statistics
- **Bot Logs**: Store activity logs with timestamps and categorization

## Key Components

### Frontend Components
- **BotControlPanel**: Main interface for starting/stopping bots and viewing status
- **ActivityConsole**: Real-time log viewer with auto-scroll functionality
- **ErrorModal**: Error handling and retry mechanisms
- **UI Components**: Comprehensive component library based on Radix UI

### Backend Services
- **MinecraftBotService**: Core bot management service handling connections and commands
- **Storage Layer**: Abstract interface with memory-based implementation for data persistence
- **WebSocket Handler**: Real-time communication between frontend and backend
- **REST API**: HTTP endpoints for bot status and commands

## Data Flow

1. **User Interaction**: User actions in the frontend trigger commands via WebSocket or REST API
2. **Bot Commands**: Backend processes commands and interfaces with Minecraft bot instances
3. **Real-time Updates**: Bot status changes and logs are broadcast to connected clients via WebSocket
4. **Data Persistence**: Bot sessions and logs are stored in PostgreSQL database
5. **State Synchronization**: Frontend state updates based on real-time server events

## External Dependencies

### Database
- **PostgreSQL**: Primary database with Neon serverless connection
- **Drizzle ORM**: Type-safe database queries and migrations
- **Connection Pooling**: Managed through @neondatabase/serverless

### Bot Integration
- **Mineflayer**: Minecraft bot creation and control library
- **WebSocket**: Real-time bidirectional communication

### UI/UX
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library
- **Font Awesome**: Additional icons for Minecraft theming

## Deployment Strategy

### Development Environment
- **Vite Dev Server**: Frontend development with hot module replacement
- **tsx**: TypeScript execution for backend development
- **Development Scripts**: Concurrent frontend and backend development

### Production Build
- **Frontend**: Vite build process generating optimized static assets
- **Backend**: esbuild bundling for Node.js deployment
- **Database**: Drizzle migrations for schema management
- **Environment**: Production-ready configuration with environment variables

### Configuration Management
- **Environment Variables**: Database connection strings and API configurations
- **TypeScript Configuration**: Shared tsconfig for consistent compilation
- **Path Aliases**: Simplified import paths for better developer experience

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- July 06, 2025. Initial setup