import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const botSessions = pgTable("bot_sessions", {
  id: serial("id").primaryKey(),
  botName: text("bot_name").notNull(),
  serverIp: text("server_ip").notNull(),
  serverPort: integer("server_port").notNull(),
  isConnected: boolean("is_connected").notNull().default(false),
  connectedAt: timestamp("connected_at"),
  disconnectedAt: timestamp("disconnected_at"),
  totalConnections: integer("total_connections").notNull().default(0),
  messagesSent: integer("messages_sent").notNull().default(0),
  errorCount: integer("error_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const botLogs = pgTable("bot_logs", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id"),
  logType: text("log_type").notNull(), // 'info', 'error', 'warning', 'success'
  message: text("message").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertBotSessionSchema = createInsertSchema(botSessions).omit({
  id: true,
  createdAt: true,
});

export const insertBotLogSchema = createInsertSchema(botLogs).omit({
  id: true,
  timestamp: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type BotSession = typeof botSessions.$inferSelect;
export type InsertBotSession = z.infer<typeof insertBotSessionSchema>;
export type BotLog = typeof botLogs.$inferSelect;
export type InsertBotLog = z.infer<typeof insertBotLogSchema>;

export interface BotStatus {
  isConnected: boolean;
  botName: string;
  uptime: string;
  playersOnline: number;
  serverStatus: 'online' | 'offline';
  totalConnections: number;
  messagesSent: number;
  errorCount: number;
}

export interface BotCommand {
  action: 'start' | 'stop' | 'reconnect' | 'clear_logs';
  serverIp?: string;
  serverPort?: number;
  botName?: string;
}

export interface ConsoleLog {
  id: string;
  timestamp: string;
  type: 'info' | 'error' | 'warning' | 'success';
  message: string;
}
