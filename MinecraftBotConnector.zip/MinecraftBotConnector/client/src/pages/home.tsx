import { useState, useEffect } from 'react';
import { BotControlPanel } from '@/components/bot-control-panel';
import { ActivityConsole } from '@/components/activity-console';
import { ErrorModal } from '@/components/error-modal';
import { BotStatus, ConsoleLog, BotCommand } from '@shared/schema';

export default function Home() {
  const [botStatus, setBotStatus] = useState<BotStatus>({
    isConnected: false,
    botName: 'MinecraftBot_001',
    uptime: '00:00:00',
    playersOnline: 0,
    serverStatus: 'offline',
    totalConnections: 0,
    messagesSent: 0,
    errorCount: 0,
  });

  const [consoleLogs, setConsoleLogs] = useState<ConsoleLog[]>([]);
  const [isConnecting, setIsConnecting] = useState(false);
  const [errorModal, setErrorModal] = useState<{ show: boolean; message: string }>({
    show: false,
    message: '',
  });

  const [ws, setWs] = useState<WebSocket | null>(null);

  useEffect(() => {
    // Initialize WebSocket connection
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      console.log('WebSocket connected');
      setWs(socket);
    };

    socket.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        
        switch (message.type) {
          case 'status':
            setBotStatus(message.data);
            break;
          case 'log':
            setConsoleLogs(prev => [...prev, message.data]);
            break;
          case 'logs':
            setConsoleLogs(message.data);
            break;
          case 'clear_logs':
            setConsoleLogs([]);
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    };

    socket.onclose = () => {
      console.log('WebSocket disconnected');
      setWs(null);
    };

    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
      setErrorModal({
        show: true,
        message: 'WebSocket connection failed. Please refresh the page.',
      });
    };

    return () => {
      socket.close();
    };
  }, []);

  const sendCommand = (command: BotCommand) => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'command', data: command }));
    }
  };

  const handleStartBot = () => {
    setIsConnecting(true);
    sendCommand({
      action: 'start',
      serverIp: 'LifeboySMP.aternos.me',
      serverPort: 43996,
      botName: 'MinecraftBot_001',
    });
    
    // Reset connecting state after a delay
    setTimeout(() => setIsConnecting(false), 5000);
  };

  const handleStopBot = () => {
    sendCommand({ action: 'stop' });
  };

  const handleReconnect = () => {
    sendCommand({ action: 'reconnect' });
  };

  const handleClearLogs = () => {
    sendCommand({ action: 'clear_logs' });
  };

  return (
    <div className="bg-gray-900 text-white min-h-screen">
      {/* Header */}
      <header className="bg-minecraft-dark border-b border-gray-700 px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <i className="fas fa-cube text-minecraft-green text-2xl"></i>
            <h1 className="text-xl font-semibold text-white">Minecraft Bot Controller</h1>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-sm text-gray-300">
              <i className="fas fa-server"></i>
              <span>LifeboySMP.aternos.me:43996</span>
            </div>
            <div className="flex items-center space-x-2 text-sm">
              <i className="fas fa-code-branch text-minecraft-blue"></i>
              <span className="text-gray-300">v1.21.7</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <BotControlPanel
              botStatus={botStatus}
              isConnecting={isConnecting}
              onStartBot={handleStartBot}
              onStopBot={handleStopBot}
              onReconnect={handleReconnect}
              onClearLogs={handleClearLogs}
            />
          </div>
          
          <div className="lg:col-span-2">
            <ActivityConsole
              logs={consoleLogs}
              botStatus={botStatus}
              isConnecting={isConnecting}
            />
          </div>
        </div>
      </main>

      <ErrorModal
        show={errorModal.show}
        message={errorModal.message}
        onClose={() => setErrorModal({ show: false, message: '' })}
        onRetry={() => {
          setErrorModal({ show: false, message: '' });
          window.location.reload();
        }}
      />
    </div>
  );
}
