import { useEffect, useRef, useState } from 'react';
import { BotStatus, ConsoleLog } from '@shared/schema';

interface ActivityConsoleProps {
  logs: ConsoleLog[];
  botStatus: BotStatus;
  isConnecting: boolean;
}

export function ActivityConsole({ logs, botStatus, isConnecting }: ActivityConsoleProps) {
  const consoleRef = useRef<HTMLDivElement>(null);
  const [autoScroll, setAutoScroll] = useState(true);

  useEffect(() => {
    if (autoScroll && consoleRef.current) {
      consoleRef.current.scrollTop = consoleRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  const getLogColor = (type: string) => {
    switch (type) {
      case 'error':
        return 'text-red-400';
      case 'success':
        return 'text-green-400';
      case 'warning':
        return 'text-yellow-400';
      default:
        return 'text-gray-300';
    }
  };

  return (
    <>
      <div className="bg-minecraft-dark rounded-lg border border-gray-700 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-white flex items-center">
            <i className="fas fa-terminal text-minecraft-green mr-2"></i>
            Activity Console
          </h2>
          <div className="flex items-center space-x-2">
            <button 
              className={`text-gray-400 hover:text-white transition-colors ${
                autoScroll ? 'text-minecraft-green' : ''
              }`}
              onClick={() => setAutoScroll(!autoScroll)}
              title="Toggle auto-scroll"
            >
              <i className="fas fa-arrow-down"></i>
            </button>
          </div>
        </div>
        
        {/* Console Output */}
        <div 
          ref={consoleRef}
          className="bg-gray-900 rounded-lg p-4 h-96 overflow-y-auto font-mono text-sm"
        >
          {logs.length === 0 ? (
            <div className="text-gray-500 space-y-2">
              <div>[{new Date().toLocaleTimeString()}] System: Console initialized</div>
              <div>[{new Date().toLocaleTimeString()}] System: Waiting for bot connection...</div>
              <div>[{new Date().toLocaleTimeString()}] System: Ready to connect to LifeboySMP.aternos.me:43996</div>
              <div>[{new Date().toLocaleTimeString()}] System: Click 'Start Bot' to begin connection</div>
            </div>
          ) : (
            logs.map((log) => (
              <div key={log.id} className={`mb-2 ${getLogColor(log.type)}`}>
                [{log.timestamp}] {log.message}
              </div>
            ))
          )}
        </div>

        {/* Connection Progress */}
        {isConnecting && (
          <div className="mt-4 bg-gray-800 rounded-lg p-4">
            <div className="flex items-center space-x-3">
              <div className="animate-spin text-minecraft-green">
                <i className="fas fa-spinner"></i>
              </div>
              <span className="text-sm text-gray-300">Connecting to server...</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2 mt-3">
              <div className="bg-minecraft-green h-2 rounded-full animate-pulse" style={{ width: '60%' }}></div>
            </div>
          </div>
        )}
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        <div className="bg-minecraft-dark rounded-lg border border-gray-700 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Total Connections</p>
              <p className="text-2xl font-semibold text-white">{botStatus.totalConnections}</p>
            </div>
            <div className="text-minecraft-green">
              <i className="fas fa-link text-xl"></i>
            </div>
          </div>
        </div>
        
        <div className="bg-minecraft-dark rounded-lg border border-gray-700 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Messages Sent</p>
              <p className="text-2xl font-semibold text-white">{botStatus.messagesSent}</p>
            </div>
            <div className="text-minecraft-blue">
              <i className="fas fa-comment text-xl"></i>
            </div>
          </div>
        </div>
        
        <div className="bg-minecraft-dark rounded-lg border border-gray-700 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Errors</p>
              <p className="text-2xl font-semibold text-white">{botStatus.errorCount}</p>
            </div>
            <div className="text-minecraft-red">
              <i className="fas fa-exclamation-triangle text-xl"></i>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
