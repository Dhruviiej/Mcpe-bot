interface ErrorModalProps {
  show: boolean;
  message: string;
  onClose: () => void;
  onRetry: () => void;
}

export function ErrorModal({ show, message, onClose, onRetry }: ErrorModalProps) {
  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-minecraft-dark rounded-lg border border-gray-700 p-6 max-w-md mx-4">
        <div className="flex items-center space-x-3 mb-4">
          <i className="fas fa-exclamation-triangle text-minecraft-red text-xl"></i>
          <h3 className="text-lg font-semibold text-white">Connection Error</h3>
        </div>
        <p className="text-gray-300 mb-6">{message}</p>
        <div className="flex justify-end space-x-3">
          <button 
            className="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200"
            onClick={onClose}
          >
            Cancel
          </button>
          <button 
            className="bg-minecraft-green hover:bg-green-600 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200"
            onClick={onRetry}
          >
            Retry
          </button>
        </div>
      </div>
    </div>
  );
}
