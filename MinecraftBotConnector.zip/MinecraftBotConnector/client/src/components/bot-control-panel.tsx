import { BotStatus } from '@shared/schema';

interface BotControlPanelProps {
  botStatus: BotStatus;
  isConnecting: boolean;
  onStartBot: () => void;
  onStopBot: () => void;
  onReconnect: () => void;
  onClearLogs: () => void;
}

export function BotControlPanel({
  botStatus,
  isConnecting,
  onStartBot,
  onStopBot,
  onReconnect,
  onClearLogs,
}: BotControlPanelProps) {
  return (
    <>
      <div className="bg-minecraft-dark rounded-lg border border-gray-700 p-6">
        <h2 className="text-lg font-semibold text-white mb-6 flex items-center">
          <i className="fas fa-robot text-minecraft-green mr-2"></i>
          Bot Control
        </h2>
        
        {/* Bot Status Card */}
        <div className="bg-gray-800 rounded-lg p-4 mb-6">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium text-gray-300">Status</span>
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${
                botStatus.isConnected 
                  ? 'bg-green-500' 
                  : 'bg-red-500 animate-pulse'
              }`}></div>
              <span className={`text-sm ${
                botStatus.isConnected 
                  ? 'text-green-400' 
                  : 'text-red-400'
              }`}>
                {botStatus.isConnected ? 'Connected' : 'Disconnected'}
              </span>
            </div>
          </div>
          
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-400">Bot Name:</span>
              <span className="text-white">{botStatus.botName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Uptime:</span>
              <span className="text-white">{botStatus.uptime}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Players Online:</span>
              <span className="text-white">{botStatus.playersOnline}</span>
            </div>
          </div>
        </div>

        {/* Primary Action Button */}
        <button 
          className={`w-full font-semibold py-3 px-4 rounded-lg transition-colors duration-200 flex items-center justify-center space-x-2 mb-4 ${
            botStatus.isConnected
              ? 'bg-minecraft-red hover:bg-red-600 text-white'
              : 'bg-minecraft-green hover:bg-green-600 text-white'
          }`}
          onClick={botStatus.isConnected ? onStopBot : onStartBot}
          disabled={isConnecting}
        >
          <i className={`fas ${botStatus.isConnected ? 'fa-stop' : 'fa-play'}`}></i>
          <span>{isConnecting ? 'Connecting...' : (botStatus.isConnected ? 'Stop Bot' : 'Start Bot')}</span>
        </button>

        {/* Secondary Actions */}
        <div className="grid grid-cols-2 gap-3">
          <button 
            className="bg-minecraft-blue hover:bg-blue-600 text-white font-medium py-2 px-3 rounded-lg transition-colors duration-200 flex items-center justify-center space-x-2 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
            onClick={onReconnect}
            disabled={!botStatus.isConnected}
          >
            <i className="fas fa-sync-alt"></i>
            <span>Reconnect</span>
          </button>
          <button 
            className="bg-minecraft-orange hover:bg-orange-600 text-white font-medium py-2 px-3 rounded-lg transition-colors duration-200 flex items-center justify-center space-x-2 text-sm"
            onClick={onClearLogs}
          >
            <i className="fas fa-trash"></i>
            <span>Clear Logs</span>
          </button>
        </div>
      </div>

      {/* Server Information Card */}
      <div className="bg-minecraft-dark rounded-lg border border-gray-700 p-6 mt-6">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
          <i className="fas fa-info-circle text-minecraft-blue mr-2"></i>
          Server Info
        </h3>
        <div className="space-y-3 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-400">Server IP:</span>
            <span className="text-white font-mono">LifeboySMP.aternos.me</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Port:</span>
            <span className="text-white font-mono">43996</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Version:</span>
            <span className="text-white">1.21 - 1.21.7</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Server Status:</span>
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${
                botStatus.serverStatus === 'online' 
                  ? 'bg-green-500' 
                  : 'bg-red-500'
              }`}></div>
              <span className={`${
                botStatus.serverStatus === 'online' 
                  ? 'text-green-400' 
                  : 'text-red-400'
              }`}>
                {botStatus.serverStatus === 'online' ? 'Online' : 'Offline'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
