import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { minecraftBotService } from "./services/minecraft-bot";
import { BotCommand } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time communication
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws) => {
    console.log('Client connected to WebSocket');
    
    // Add client to bot service
    minecraftBotService.addClient(ws);

    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'command') {
          const command: BotCommand = message.data;
          await minecraftBotService.handleCommand(command);
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
    });
  });

  // REST API endpoints
  app.get('/api/bot/status', async (req, res) => {
    try {
      const status = minecraftBotService.getStatus();
      res.json(status);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/bot/command', async (req, res) => {
    try {
      const command: BotCommand = req.body;
      await minecraftBotService.handleCommand(command);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  return httpServer;
}
