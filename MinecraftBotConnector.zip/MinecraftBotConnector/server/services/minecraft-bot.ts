import { createBot, Bot } from 'mineflayer';
import { WebSocket } from 'ws';
import { BotStatus, ConsoleLog, BotCommand } from '@shared/schema';
import { storage } from '../storage';

export class MinecraftBotService {
  private bot: Bot | null = null;
  private connectedClients: WebSocket[] = [];
  private startTime: Date | null = null;
  private sessionId: number | null = null;
  private stats = {
    totalConnections: 0,
    messagesSent: 0,
    errorCount: 0,
  };

  constructor() {}

  addClient(ws: WebSocket) {
    this.connectedClients.push(ws);
    this.sendStatus();
    this.sendRecentLogs();
    
    ws.on('close', () => {
      this.connectedClients = this.connectedClients.filter(client => client !== ws);
    });
  }

  private broadcast(data: any) {
    const message = JSON.stringify(data);
    this.connectedClients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  private async log(message: string, type: 'info' | 'error' | 'warning' | 'success' = 'info') {
    const logEntry: ConsoleLog = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toLocaleTimeString(),
      type,
      message,
    };

    // Store in database if session exists
    if (this.sessionId) {
      await storage.createBotLog({
        sessionId: this.sessionId,
        logType: type,
        message,
      });
    }

    this.broadcast({ type: 'log', data: logEntry });
  }

  private sendStatus() {
    const status: BotStatus = {
      isConnected: this.bot?.player?.username ? true : false,
      botName: this.bot?.username || 'MinecraftBot_001',
      uptime: this.getUptime(),
      playersOnline: this.bot?.players ? Object.keys(this.bot.players).length : 0,
      serverStatus: this.bot?.player?.username ? 'online' : 'offline',
      totalConnections: this.stats.totalConnections,
      messagesSent: this.stats.messagesSent,
      errorCount: this.stats.errorCount,
    };

    this.broadcast({ type: 'status', data: status });
  }

  private async sendRecentLogs() {
    if (this.sessionId) {
      const logs = await storage.getRecentBotLogs(this.sessionId, 50);
      const consoleLogs: ConsoleLog[] = logs.map(log => ({
        id: log.id.toString(),
        timestamp: log.timestamp.toLocaleTimeString(),
        type: log.logType as any,
        message: log.message,
      }));
      
      this.broadcast({ type: 'logs', data: consoleLogs });
    }
  }

  private getUptime(): string {
    if (!this.startTime) return '00:00:00';
    
    const elapsed = Date.now() - this.startTime.getTime();
    const hours = Math.floor(elapsed / 3600000);
    const minutes = Math.floor((elapsed % 3600000) / 60000);
    const seconds = Math.floor((elapsed % 60000) / 1000);
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }

  async handleCommand(command: BotCommand) {
    try {
      switch (command.action) {
        case 'start':
          await this.startBot(command.serverIp || 'LifeboySMP.aternos.me', command.serverPort || 43996, command.botName || 'MinecraftBot_001');
          break;
        case 'stop':
          await this.stopBot();
          break;
        case 'reconnect':
          await this.reconnectBot();
          break;
        case 'clear_logs':
          await this.clearLogs();
          break;
      }
    } catch (error) {
      await this.log(`Command failed: ${error.message}`, 'error');
      this.stats.errorCount++;
      this.sendStatus();
    }
  }

  private async startBot(host: string, port: number, username: string) {
    if (this.bot) {
      await this.log('Bot is already running', 'warning');
      return;
    }

    await this.log('Starting bot connection...', 'info');
    
    // Create session
    this.sessionId = await storage.createBotSession({
      botName: username,
      serverIp: host,
      serverPort: port,
      isConnected: false,
      connectedAt: null,
      disconnectedAt: null,
      totalConnections: this.stats.totalConnections,
      messagesSent: this.stats.messagesSent,
      errorCount: this.stats.errorCount,
    });

    try {
      await this.log(`Attempting to connect to ${host}:${port}`, 'info');
      
      this.bot = createBot({
        host,
        port,
        username,
        version: '1.21.7',
        auth: 'offline',
      });

      this.bot.on('login', async () => {
        this.startTime = new Date();
        this.stats.totalConnections++;
        
        await this.log(`Successfully connected as ${username}`, 'success');
        await this.log(`Logged in to server: ${host}:${port}`, 'success');
        
        // Update session
        if (this.sessionId) {
          await storage.updateBotSession(this.sessionId, {
            isConnected: true,
            connectedAt: new Date(),
            totalConnections: this.stats.totalConnections,
          });
        }
        
        this.sendStatus();
      });

      this.bot.on('spawn', async () => {
        await this.log('Bot spawned in the world', 'info');
        this.sendStatus();
      });

      this.bot.on('chat', async (username, message) => {
        if (username === this.bot?.username) return;
        await this.log(`<${username}> ${message}`, 'info');
        this.stats.messagesSent++;
        this.sendStatus();
      });

      this.bot.on('error', async (err) => {
        await this.log(`Bot error: ${err.message}`, 'error');
        this.stats.errorCount++;
        this.sendStatus();
      });

      this.bot.on('end', async () => {
        await this.log('Bot disconnected from server', 'warning');
        
        // Update session
        if (this.sessionId) {
          await storage.updateBotSession(this.sessionId, {
            isConnected: false,
            disconnectedAt: new Date(),
            messagesSent: this.stats.messagesSent,
            errorCount: this.stats.errorCount,
          });
        }
        
        this.bot = null;
        this.startTime = null;
        this.sendStatus();
      });

      this.bot.on('kicked', async (reason) => {
        await this.log(`Bot was kicked: ${reason}`, 'error');
        this.stats.errorCount++;
        this.sendStatus();
      });

    } catch (error) {
      await this.log(`Failed to connect: ${error.message}`, 'error');
      this.stats.errorCount++;
      this.bot = null;
      this.sendStatus();
    }
  }

  private async stopBot() {
    if (!this.bot) {
      await this.log('Bot is not running', 'warning');
      return;
    }

    await this.log('Stopping bot...', 'info');
    this.bot.quit();
    this.bot = null;
    this.startTime = null;
    this.sendStatus();
  }

  private async reconnectBot() {
    if (!this.bot) {
      await this.log('Cannot reconnect: bot is not running', 'warning');
      return;
    }

    const host = this.bot.options.host;
    const port = this.bot.options.port;
    const username = this.bot.username;

    await this.stopBot();
    await new Promise(resolve => setTimeout(resolve, 2000));
    await this.startBot(host, port, username);
  }

  private async clearLogs() {
    if (this.sessionId) {
      await storage.clearBotLogs(this.sessionId);
    }
    this.broadcast({ type: 'clear_logs' });
    await this.log('Console cleared', 'info');
  }

  getStatus(): BotStatus {
    return {
      isConnected: this.bot?.player?.username ? true : false,
      botName: this.bot?.username || 'MinecraftBot_001',
      uptime: this.getUptime(),
      playersOnline: this.bot?.players ? Object.keys(this.bot.players).length : 0,
      serverStatus: this.bot?.player?.username ? 'online' : 'offline',
      totalConnections: this.stats.totalConnections,
      messagesSent: this.stats.messagesSent,
      errorCount: this.stats.errorCount,
    };
  }
}

export const minecraftBotService = new MinecraftBotService();
