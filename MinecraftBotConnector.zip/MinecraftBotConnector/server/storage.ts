import { 
  users, 
  botSessions, 
  botLogs, 
  type User, 
  type InsertUser, 
  type BotSession, 
  type InsertBotSession, 
  type BotLog, 
  type InsertBotLog 
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createBotSession(session: InsertBotSession): Promise<number>;
  updateBotSession(id: number, updates: Partial<BotSession>): Promise<void>;
  getBotSession(id: number): Promise<BotSession | undefined>;
  
  createBotLog(log: InsertBotLog): Promise<BotLog>;
  getRecentBotLogs(sessionId: number, limit: number): Promise<BotLog[]>;
  clearBotLogs(sessionId: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private botSessions: Map<number, BotSession>;
  private botLogs: Map<number, BotLog>;
  private currentUserId: number;
  private currentSessionId: number;
  private currentLogId: number;

  constructor() {
    this.users = new Map();
    this.botSessions = new Map();
    this.botLogs = new Map();
    this.currentUserId = 1;
    this.currentSessionId = 1;
    this.currentLogId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createBotSession(session: InsertBotSession): Promise<number> {
    const id = this.currentSessionId++;
    const botSession: BotSession = {
      ...session,
      id,
      createdAt: new Date(),
    };
    this.botSessions.set(id, botSession);
    return id;
  }

  async updateBotSession(id: number, updates: Partial<BotSession>): Promise<void> {
    const session = this.botSessions.get(id);
    if (session) {
      this.botSessions.set(id, { ...session, ...updates });
    }
  }

  async getBotSession(id: number): Promise<BotSession | undefined> {
    return this.botSessions.get(id);
  }

  async createBotLog(log: InsertBotLog): Promise<BotLog> {
    const id = this.currentLogId++;
    const botLog: BotLog = {
      ...log,
      id,
      timestamp: new Date(),
    };
    this.botLogs.set(id, botLog);
    return botLog;
  }

  async getRecentBotLogs(sessionId: number, limit: number): Promise<BotLog[]> {
    const logs = Array.from(this.botLogs.values())
      .filter(log => log.sessionId === sessionId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
    
    return logs.reverse(); // Return in chronological order
  }

  async clearBotLogs(sessionId: number): Promise<void> {
    const logsToDelete = Array.from(this.botLogs.entries())
      .filter(([_, log]) => log.sessionId === sessionId)
      .map(([id, _]) => id);
    
    logsToDelete.forEach(id => this.botLogs.delete(id));
  }
}

export const storage = new MemStorage();
